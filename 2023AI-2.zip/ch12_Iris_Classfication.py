import pandas as pd

# 아이리스 데이터를 불러옵니다.
df = pd.read_csv('./data/iris3.csv')

# 첫 5줄을 봅니다.
print(df.head())

import seaborn as sns
import matplotlib.pyplot as plt

#sepal꽃받침  petal 꽃잎 species 종
# 그래프로 확인해 봅시다.

#colormap = plt.summer()
#sns.pairplot(df, hue='species')
#pairplot 산점도, 상관도
#hue : 색어떤 카테고리를 중심으로 그래프를 그릴지 결정
sns.pairplot(df, hue='species',palette="husl",vars=['sepal_length', 'petal_length']) #관계그래프 https://steadiness-193.tistory.com/198
#hue='species' :다른 항목은 행렬을 만들수 없다
plt.show()

# 속성을 X, 클래스를 y로 저장합니다.
X = df.iloc[:,0:4]
y = df.iloc[:,4]

# X와 y의 첫 5줄을 출력해 보겠습니다.
print(X[0:5])
print(y[0:5])

# 원-핫 인코딩 처리를 합니다.
yy = pd.get_dummies(y)

# 원-핫 인코딩 결과를 확인합니다.
print('--------------')
#y.replace((True,False) , (1,0) , inplace = True) #Bool값을 정수로
print(yy[0:5])

from keras.models import Sequential
from keras.layers import Dense

# 모델 설정
model = Sequential()
model.add(Dense(12,  input_dim=4, activation='relu'))
model.add(Dense(8,  activation='relu'))
model.add(Dense(3, activation='softmax'))
model.summary()

# 모델 컴파일
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# 모델 실행
history=model.fit(X, yy, epochs=30, batch_size=5)

import numpy as np

xx=[ [6.1,3,4.6,1.4]]
print(model.predict(xx))
pre=np.argmax(model.predict(xx)) #argmax:집합 X 안에서 최대값의 위치
print(pre)
Y_col=np.unique(y) #열 이름 중복 제거
print(Y_col)
print('Y_col===',Y_col)
print(Y_col[pre])