#!/usr/bin/env python
# -*- coding: utf-8 -*-

from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import LabelEncoder #문자를 숫자화
  #scikit-learn  인스톨

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf

# 데이터 입력
df = pd.read_csv('iris3.csv')

# 데이터 분류
#print(df.info())
dataset = df.values #numpy 타입으로 변환
#print(dataset)
print(dataset.shape)
print(df.dtypes)  #판다스 파일 데이터타입
print(dataset.dtype)  #object는 문자열

X = dataset[:,0:4].astype(float)
print(X.dtype)
print(X)
Y_obj = dataset[:,4]

#print(df)
e = LabelEncoder()# 문자열을 숫자로 변환 객체
e.fit(Y_obj) # 문자열 피처는 일반적으로 카테고리형과 텍스트형 분류
print(Y_obj)
Y = e.transform(Y_obj) #수치데이터로 전환
print(Y)

print(df.columns)
df.drop('species', axis=1, inplace=True)
print(df.columns)
#df=pd.concat([df,Y],axis=1) #pandas + numpy형식이므로 에러
df_Y = pd.DataFrame(Y) #numpy를 pandas로 변환
df_Y.columns=["species"]
df=pd.concat([df,df_Y],axis=1)
print(df)
colormap = plt.summer()
sns.heatmap(df.corr(),linewidths=0.1,vmax=0.5, cmap=colormap, linecolor='white', annot=True)
plt.show()

Y_encoded = tf.keras.utils.to_categorical(Y)
#Y = e.fit_transform(Y_obj)  # fit + transform
print(Y_encoded)
# 모델의 설정
model = Sequential()
model.add(Dense(16,  input_dim=4, activation='relu'))
model.add(Dense(3, activation='softmax'))

# 모델 컴파일
model.compile(loss='categorical_crossentropy', #데이터 결과 값이 0 또는 1 인 경우에는  binary_crossentropy
                                              # one hot encoding 인 경우: categorical_crossentropy
            optimizer='adam',
            metrics=['accuracy'])

# 모델 실행
model.fit(X, Y_encoded, epochs=50, batch_size=1)

# 결과 출력
print("\n Accuracy: %.4f" % (model.evaluate(X, Y_encoded)[1]))

eval = model.evaluate(X, Y_encoded, verbose=0)
print('정답률 = ', eval[1],'loss=', eval[0])

eval = model.evaluate(X, Y_encoded, verbose=0)
print('손실값 = ', eval[0],'loss=', eval[0])

xx=[ [6.1,3,4.6,1.4]]
print(model.predict(xx))
y=np.argmax(model.predict(xx)) #argmax:집합 X 안에서 최대값의 위치
print(y)
Y_col=np.unique(Y_obj) #열 이름 중복 제거
print(Y_col)
print(Y_col[y])